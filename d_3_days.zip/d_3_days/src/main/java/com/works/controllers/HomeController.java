package com.works.controllers;

import com.google.gson.Gson;
import com.works.models.jsonProduct.Bilgiler;
import com.works.models.jsonProduct.ProductData;
import com.works.models.newsp.Article;
import com.works.models.newsp.NewsData;
import com.works.props.AjaxPullData;
import com.works.services.ProductService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Controller
public class HomeController {

    final ProductService pService;
    public HomeController( ProductService pService ) {
        this.pService = pService;
    }

    @GetMapping("")
    public String home(Model model) {
        model.addAttribute("products", pService.getProducts());
        return "home";
    }


    @PostMapping("/news")
    @ResponseBody
    public List<Article> news( @RequestBody AjaxPullData pullData ) {
        String url = "https://newsapi.org/v2/top-headlines?country="+pullData.getCountry()+"&category=business&apiKey=38a9e086f10b445faabb4461c4aa71f8";
        RestTemplate restTemplate = new RestTemplate();
        String sData = restTemplate.getForObject(url, String.class);
        Gson gson = new Gson();
        try {
            NewsData newsData = gson.fromJson(sData, NewsData.class);
            return newsData.getArticles();
        }catch (Exception ex) {}
        return new ArrayList<Article>();
    }


}
