package com.works.services;

import com.google.gson.Gson;
import com.works.models.jsonProduct.Bilgiler;
import com.works.models.jsonProduct.ProductData;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductService {

    @Cacheable(value = "getProducts")
    public List<Bilgiler> getProducts() {
        System.out.println("getProducts Call");
        String url = "https://www.jsonbulut.com/json/product.php?ref=5380f5dbcc3b1021f93ab24c3a1aac24&start=0";
        RestTemplate restTemplate = new RestTemplate();
        String data = restTemplate.getForObject(url, String.class);
        Gson gson = new Gson();
        try {
            ProductData productData = gson.fromJson(data, ProductData.class);
            return productData.getProducts().get(0).getBilgiler();
            /*
            productData.getProducts().get(0).getBilgiler().forEach( item -> {
                System.out.println( item.getProductName() );
            });
             */
        }catch (Exception ex) {
            System.err.println("json data  error : " + ex);
        }

        return new ArrayList<Bilgiler>();
    }

}
