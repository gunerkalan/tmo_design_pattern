$(document).ready(function () {

    $("#btnNews").click(function () {
        ajaxNews();
    })


    function ajaxNews() {

        $("#divNews").html('<img src="../img/preloader.gif" style="width: 75px;" />');

        var country = $('#countryTxt').val();
        if (country === "") {
            country = "tr";
        }

        const pushData = {
            "country": country
        }

        // ajax model
        $.ajax({
            type: 'post',
            contentType: 'application/json',
            url: '/news',
            data: JSON.stringify(pushData),
            success: function (data) {
                $("#divNews").html( tableCreate(data) );
                const count = data.length;
                $("#newH1").html("News - " + count);
            },
            error: function (error) {
                console.log(error)
            }
        })
    }

    function tableCreate( data ) {
        var html = '<table class="table table-hover">\n' +
            '  <thead>\n' +
            '    <tr>\n' +
            '      <th scope="col">Image</th>\n' +
            '      <th scope="col">author</th>\n' +
            '      <th scope="col">title</th>\n' +
            '      <th scope="col">description</th>\n' +
            '    </tr>\n' +
            '  </thead>\n' +
            '  <tbody>'

        data.map( item => {
            html += '<tr>\n' +
                '      <th><a href="'+item.url+'" target="_blank" ><img src="'+item.urlToImage+'" style="width: 150px"; /></a> </th>\n' +
                '      <td>'+item.source.name+'</td>\n' +
                '      <td>'+item.title+'</td>\n' +
                '      <td>'+item.description+'</td>\n' +
                '    </tr>'
        })



        html += ' </tbody>\n' +
            '</table>'

        return html;
    }

    ajaxNews();

})