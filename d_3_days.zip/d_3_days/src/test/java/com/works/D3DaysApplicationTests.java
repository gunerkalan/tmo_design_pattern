package com.works;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D3DaysApplicationTests {

    @Test
    void contextLoads() {
    }

}
