package com.works.l_5_objPool;

public class Connection {

    public void connect( int number, Connection con ) {
        System.out.println("Connection connect " + number);

        DataSource.relase(con);
    }

}
