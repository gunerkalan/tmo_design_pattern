package com.works.l_5_objPool;

public class MainPool {

    public static void main(String[] args) throws Exception {

        Connection c1 = DataSource.getConnection();
        Connection c2 = DataSource.getConnection();
        Connection c3 = DataSource.getConnection();

        c1.connect(10, c1);
        c2.connect(20, c2);
        c3.connect(30, c3);


        Runnable rn = () -> {
            for (int i = 0; i < 100; i++) {
                Connection cn = null;
                try {
                    cn = DataSource.getConnection();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                cn.connect(i, cn);
            }
        };
        Thread th1= new Thread(rn);

        System.out.println("==================================");

        Runnable rn1 = () -> {
            for (int i = 100; i < 200; i++) {
                Connection cn = null;
                try {
                    cn = DataSource.getConnection();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                cn.connect(i, cn);
            }
        };
        Thread th2 =  new Thread(rn1);

        th1.start();
        th1.join();

        th2.start();
        th2.join();










    }

}
