package com.works.l_5_objPool;

import java.util.ArrayList;
import java.util.List;

public class DataSource {

    static DataSource instance = new DataSource();

    List<Connection> pool = new ArrayList<>();

    public DataSource() {
        for (int i = 0; i < 3; i++) {
            pool.add(new Connection());
        }
    }

    static Connection getConnection() throws Exception {

        if (instance.pool.size() == 0) {
            throw new Exception();
        }

        Connection con = instance.pool.get(0);
        instance.pool.remove(0);

        System.out.println(con);

        return con;
    }


    public static void relase( Connection con ) {
        if ( con != null ) {
            instance.pool.add(con);
        }
    }


}
