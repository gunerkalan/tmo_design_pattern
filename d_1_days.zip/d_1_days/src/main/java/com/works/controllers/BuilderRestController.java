package com.works.controllers;

import com.works.l_4_builder.SiparisYonetimi;
import com.works.l_4_builder.Urun;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
public class BuilderRestController {

    @PostMapping("/order")
    public Map<String, Object> order(@RequestBody Urun urun) {
        Map<String, Object> hm = new LinkedHashMap<>();
        hm.put("Order", new SiparisYonetimi().order(urun) );
        return hm;
    }

}
