package com.works.controllers;

import com.works.b_1_factory.MemurYonetim;
import com.works.b_1_factory.MudurYonetim;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

@RestController
public class FactoryRestController {

    Random rd = new Random();
    Map<String, Object> hm = new LinkedHashMap<>();

    final MemurYonetim memurYonetim;
    final MudurYonetim mudurYonetim;
    public FactoryRestController( MemurYonetim memurYonetim, MudurYonetim mudurYonetim ) {
        this.memurYonetim = memurYonetim;
        this.mudurYonetim = mudurYonetim;
        System.out.println("Kurucu : " + rd);
    }

    @GetMapping("/personList")
    public Map<String, Object> personList(@RequestParam String tur) {
        hm.clear();

        if (tur.equals("mudur")) {
            hm.put("personel", mudurYonetim.getPersonels());
        }

        if (tur.equals("memur")) {
            hm.put("personel", memurYonetim.getPersonels());
        }

        System.out.println(rd);

        return hm;
    }

}
