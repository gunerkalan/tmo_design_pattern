package com.works.l_2_factoryMethod;

public class PDF implements Dokuman {

    @Override
    public String getType() {
        return "pdf";
    }

}
