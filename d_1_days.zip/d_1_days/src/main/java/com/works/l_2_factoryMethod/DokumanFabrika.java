package com.works.l_2_factoryMethod;

public class DokumanFabrika {

    public static Dokuman olustur( String type ) {

        if ( type.equals("pdf") ) {
            return new PDF();
        }else if ( type.equals("word") ) {
            return new WORD();
        }else {
            throw new RuntimeException("Tür Hatası");
        }

    }

}
