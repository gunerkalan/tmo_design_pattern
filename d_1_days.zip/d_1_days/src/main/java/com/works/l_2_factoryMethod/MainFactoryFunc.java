package com.works.l_2_factoryMethod;

public class MainFactoryFunc {

    public static void main(String[] args) {

        Dokuman pdf = new DokumanFabrika().olustur("pdf");
        System.out.println(pdf.getType());

        Dokuman word = new DokumanFabrika().olustur("word");
        System.out.println(word.getType());

    }


}
