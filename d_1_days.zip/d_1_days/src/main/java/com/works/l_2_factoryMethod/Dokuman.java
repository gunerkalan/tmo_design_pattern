package com.works.l_2_factoryMethod;

public interface Dokuman {

    String getType();

}
