package com.works.l_2_factoryMethod;

public class WORD implements Dokuman {

    @Override
    public String getType() {
        return "word";
    }

}
