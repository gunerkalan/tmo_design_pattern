package com.works.l_3_singleton;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Random;

public class DB {

    private static DB instance = null;
    private static Object lock = new Object();

    private Connection con = null;
    public Random rd = null;

    public DB() {
        System.out.println("DB Call");
        try {
            rd = new Random();
            con = DriverManager.getConnection("","","");
        }catch (Exception ex) {

        }
    }

    public static DB instance() {
        if ( instance == null ) {
            synchronized (lock) {
                if ( instance == null ) {
                    instance = new DB();
                }
            }
        }
        return instance;
    }

    public String close(int i) {
        return "DB Close i : " + i;
    }

}
