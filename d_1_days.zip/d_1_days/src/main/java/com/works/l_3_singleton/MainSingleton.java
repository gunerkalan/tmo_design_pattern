package com.works.l_3_singleton;

public class MainSingleton {

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            Runnable rn = () -> {
                DB db = DB.instance();
                System.out.println( db + " - " + db.rd.nextInt(100) );
            };
            new Thread(rn).start();
        }


    }

}
