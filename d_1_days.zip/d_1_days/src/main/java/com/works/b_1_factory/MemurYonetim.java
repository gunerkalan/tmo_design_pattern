package com.works.b_1_factory;

import org.springframework.stereotype.Service;

@Service
public class MemurYonetim extends PersonelYonetim {

    @Override
    public void personelUret() {

        for (int i = 0; i < 10 ; i++) {
            Memur memur = new Memur("Mehmet"+i, "12345678", 1);
            getPersonels().add(memur);
        }
    }

}
