package com.works.b_1_factory;

import org.springframework.stereotype.Service;

@Service
public class MudurYonetim extends PersonelYonetim {

    @Override
    public void personelUret() {
        Mudur m1 = new Mudur("Ali", "234567", 2);
        Mudur m2 = new Mudur("Veli", "765432", 3);
        Mudur m3 = new Mudur("Hasan", "98765123", 2);
        getPersonels().add(m1);
        getPersonels().add(m2);
        getPersonels().add(m3);
    }


}
