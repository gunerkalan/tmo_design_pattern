package com.works.b_1_factory;

public class Mudur extends Personel {

    public Mudur(String adi, String kimlik, int katsayi) {
        super(adi, kimlik, katsayi);
    }

}
