package com.works.b_1_factory;

public class Memur extends  Personel {

    public Memur(String adi, String kimlik, int katsayi) {
        super(adi, kimlik, katsayi);
    }

}
