package com.works.b_1_factory;

public abstract class Personel {

    private String adi = null;
    private String kimlik = null;
    private int katsayi = 0;

    public Personel(String adi, String kimlik, int katsayi) {
        this.adi = adi;
        this.kimlik = kimlik;
        this.katsayi = katsayi;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getKimlik() {
        return kimlik;
    }

    public void setKimlik(String kimlik) {
        this.kimlik = kimlik;
    }

    public int getKatsayi() {
        return katsayi;
    }

    public void setKatsayi(int katsayi) {
        this.katsayi = katsayi;
    }
}
