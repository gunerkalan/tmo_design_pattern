package com.works.b_1_factory;

import java.util.ArrayList;

public abstract class PersonelYonetim {

    public PersonelYonetim() {
        personelUret();
    }

    public abstract void personelUret();

    private ArrayList<Personel> personels = new ArrayList<>();

    public ArrayList<Personel> getPersonels() {
        return personels;
    }

    public void setPersonels(ArrayList<Personel> personels) {
        this.personels = personels;
    }
}
