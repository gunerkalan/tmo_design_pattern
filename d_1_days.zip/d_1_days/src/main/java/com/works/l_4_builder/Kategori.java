package com.works.l_4_builder;

public class Kategori {

    private int kId;
    private String kName;

    public Kategori(int kId, String kName) {
        this.kId = kId;
        this.kName = kName;
    }

    public int getkId() {
        return kId;
    }

    public void setkId(int kId) {
        this.kId = kId;
    }

    public String getkName() {
        return kName;
    }

    public void setkName(String kName) {
        this.kName = kName;
    }
}
