package com.works.l_4_builder;

public abstract class SiparisBuilder {

    private Urun urun = null;

    public Urun getUrun() {
        if ( urun == null ) {
            urun = new Urun();
        }
        return urun;
    }

    public abstract void setTitle( String title );
    public abstract void setKategori( int kId, String kName );
    public abstract void setKampanya( int kaid, boolean status );
    public abstract void setPrice( int price );


}
