package com.works.l_4_builder;

public class SiparisYonetimi {

    private SiparisBuilder builder;

    public Urun order( Urun urun ) {

        if (urun.getkName().equals("tablet")) {
            builder = new TabletSiparisBuilder();
        }else if (urun.getkName().equals("telefon")) {
            builder = new TelefonSiparisBuilder();
        }

        builder.setTitle(urun.getTitle());
        builder.setKategori(urun.getkId(), urun.getkName());
        builder.setKampanya(urun.getKaid(), urun.isStatus());
        builder.setPrice(urun.getPrice());

        return builder.getUrun();
    }

}
