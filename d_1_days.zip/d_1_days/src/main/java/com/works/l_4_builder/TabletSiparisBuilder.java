package com.works.l_4_builder;

public class TabletSiparisBuilder extends SiparisBuilder {

    @Override
    public void setTitle(String title) {
        getUrun().setTitle(title);
    }

    @Override
    public void setKategori(int kId, String kName) {
        getUrun().setKategori(new Kategori(kId, kName));
    }

    @Override
    public void setKampanya(int kaid, boolean status) {
        getUrun().setKampanya(new Kampanya(status, kaid ));
    }

    @Override
    public void setPrice(int price) {
        getUrun().setPrice(price);
    }
}
