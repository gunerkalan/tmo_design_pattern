package com.works.l_4_builder;

public class Kampanya {

    private boolean status;
    private int kaid = 0;

    public Kampanya(boolean status, int kaid) {
        this.status = status;
        this.kaid = kaid;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getKaid() {
        return kaid;
    }

    public void setKaid(int kaid) {
        this.kaid = kaid;
    }
}
