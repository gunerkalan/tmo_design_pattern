package com.works.l_1_factory;

public class I320 extends Car {

    public I320( int guc) {
        super("BMW", "i320", guc);
    }

}
