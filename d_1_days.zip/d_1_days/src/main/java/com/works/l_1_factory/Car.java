package com.works.l_1_factory;

public abstract class Car {

    private String marka = null;
    private String model = null;
    private int guc = 0;

    public Car(String marka, String model, int guc) {
        this.marka = marka;
        this.model = model;
        this.guc = guc;
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getGuc() {
        return guc;
    }

    public void setGuc(int guc) {
        this.guc = guc;
    }
}
