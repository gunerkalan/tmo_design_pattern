package com.works.l_1_factory;

public class AudiFabrika extends ArabaFabrika {

    @Override
    public void createCar() {
        A3 a3 = new A3(120);
        getCarList().add(a3);
    }

    public void zenonFar() {
        System.out.println("zenonFar Call");
    }

}
