package com.works.l_1_factory;

public class A3 extends Car {

    public A3( int guc ) {
        super("Audi", "A3", guc);
    }

}
