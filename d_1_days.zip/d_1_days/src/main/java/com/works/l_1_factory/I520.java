package com.works.l_1_factory;

public class I520 extends Car {

    public I520(int guc) {
        super("BMW", "I520", guc);
    }

}
