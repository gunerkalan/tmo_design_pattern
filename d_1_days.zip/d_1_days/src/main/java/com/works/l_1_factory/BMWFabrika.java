package com.works.l_1_factory;

public class BMWFabrika extends ArabaFabrika {

    @Override
    public void createCar() {
        I520 i520 = new I520(140);
        I320 i320 = new I320(120);
        getCarList().add(i520);
        getCarList().add(i320);
    }

}
