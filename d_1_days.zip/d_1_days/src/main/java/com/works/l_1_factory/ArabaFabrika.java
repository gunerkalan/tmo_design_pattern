package com.works.l_1_factory;

import java.util.ArrayList;

public abstract class ArabaFabrika {

    public ArabaFabrika() {
        createCar();
    }

    private ArrayList<Car> carList = new ArrayList<>();

    public abstract void createCar();

    public ArrayList<Car> getCarList() {
        return carList;
    }

    public void setCarList(ArrayList<Car> carList) {
        this.carList = carList;
    }
}
