package com.works.l_1_factory;

public class MainFactory {

    public static void main(String[] args) {

        ArabaFabrika audi = new AudiFabrika();
        ArabaFabrika bwm = new BMWFabrika();

        list(audi);
        list(bwm);

    }

    public static void list( ArabaFabrika fabrika ) {

        fabrika.getCarList().forEach( item -> {
            System.out.println(item.getModel() + " " + item.getGuc());
        });

        if ( fabrika instanceof AudiFabrika ) {
            AudiFabrika audiFabrika = (AudiFabrika) fabrika;
            audiFabrika.zenonFar();
        }

    }


}
