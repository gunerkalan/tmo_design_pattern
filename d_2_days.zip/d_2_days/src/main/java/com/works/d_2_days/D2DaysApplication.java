package com.works.d_2_days;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D2DaysApplication {

    public static void main(String[] args) {
        SpringApplication.run(D2DaysApplication.class, args);
    }

}
