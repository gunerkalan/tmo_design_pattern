package com.works.d_2_days.controllers;

import com.works.d_2_days.utils.Util;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class IncluderController {

    final Util util;
    public IncluderController( Util util ) {
        this.util = util;
    }

    @GetMapping("/navmenu")
    public String navmenu(Model model) {
        model.addAttribute("user", util.info() );
        return "inc/navmenu";
    }


}
