package com.works.d_2_days.controllers;

import com.works.d_2_days.entities.Note;
import com.works.d_2_days.repositories.NoteRepository;
import com.works.d_2_days.utils.Util;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class DashboardController {

    final Util util;
    final NoteRepository nRepo;
    public DashboardController( Util util, NoteRepository nRepo ) {
        this.util = util;
        this.nRepo = nRepo;
    }


    boolean status = false;
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        if (status) {
            model.addAttribute("status", status);
            status = false;
        }
        model.addAttribute("notes", nRepo.findAll());
        return util.control("dashboard");
    }


    @PostMapping("/noteInsert")
    public String noteInsert(Note note) {
        if ( nRepo.save(note) != null ){
            status = true;
            return "redirect:/dashboard";
        }
        return util.control("dashboard");
    }


    @GetMapping("/deleteNote/{nid}")
    public String deleteNote(@PathVariable String nid) {

        try {
            int convertNid = Integer.parseInt(nid);
            nRepo.deleteById(convertNid);
            return "redirect:/dashboard";
        }catch (Exception ex) {

        }
        util.logout();
        return "redirect:/";

    }

}
