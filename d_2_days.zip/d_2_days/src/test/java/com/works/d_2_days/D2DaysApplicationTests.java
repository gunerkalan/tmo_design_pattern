package com.works.d_2_days;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class D2DaysApplicationTests {

    @Test
    void contextLoads() {
    }

}
